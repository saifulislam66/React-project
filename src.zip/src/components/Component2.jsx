import React from "react";

const Component2 = () => {
  return <div>components2</div>;
};

export default Component2;
