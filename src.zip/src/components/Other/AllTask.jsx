import React from "react";

function AllTask() {
  return (
    <div className=" bg-zinc-500 p-5 h-52 overflow-auto rounded mt-5">
      <div className="bg-red-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
      <div className="bg-violet-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
      <div className="bg-green-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
      <div className="bg-fuchsia-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
      <div className="bg-orange-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
      <div className="bg-red-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
      <div className="bg-red-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
      <div className="bg-red-400 mb-2 py-2 px-5 flex  justify-between rounded">
        <h2>saiful</h2>
        <h3>Make a Web Design</h3>
        <h5>Status</h5>
      </div>
    </div>
  );
}

export default AllTask;
