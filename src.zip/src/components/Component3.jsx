import React from "react";

const Component3 = () => {
  return <div>components3</div>;
};

export default Component3;
