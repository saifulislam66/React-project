import React from "react";

const Component1 = () => {
  return <div>components1</div>;
};

export default Component1;
