import React from "react";

const About = () => {
  return (
    <div>
      <h1 className="text-red-700">about</h1>
    </div>
  );
};

export default About;
